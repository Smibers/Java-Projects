package com.example.BigPiggie;

public class Computer {
    private String name;
    private int pointTotal;
    public Computer(String name) {
        this.name = name;
        this.pointTotal = 0;
    }
}
